To start the game, run Color_game.exe.
No need to install anything.